# SM RO WATER SERVICE — OWNER APP + FCM

Android package: `com.smwater.service.owner`

## APK build
The GitHub Actions workflow builds the debug APK using JDK 17 + Gradle 8.7.

## Firebase push notification flow
1. Owner app obtains an FCM registration token.
2. After owner login, the token is saved to Firestore collection `ownerTokens`.
3. Firebase Cloud Function `notifyOwnerNewOrder` watches `orders/{orderId}`.
4. When a new order is created, the function sends an FCM push notification to all registered owner tokens.

## Deploy the notification function
From the project root, install Firebase CLI and run:

`firebase login`

`firebase use sm-water-service-e1b48`

`firebase deploy --only functions:notifyOwnerNewOrder`

If prompted, enable Cloud Functions / Eventarc billing requirements for the Firebase project.

## Firestore rules
Merge the `ownerTokens` rule from `firestore-owner-rules.txt` into the existing Firestore rules.
