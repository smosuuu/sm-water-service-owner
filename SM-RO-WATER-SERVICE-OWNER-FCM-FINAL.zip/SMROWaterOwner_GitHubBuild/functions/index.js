const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();
const db = getFirestore();
const OWNER_UID = "P155BtHtCGZHTBbhxvg40RvFSP83";

exports.notifyOwnerNewOrder = onDocumentCreated(
  { document: "orders/{orderId}", region: "asia-south1" },
  async (event) => {
    const snap = event.data;
    if (!snap) return;
    const order = snap.data() || {};

    const tokensSnap = await db.collection("ownerTokens")
      .where("ownerUid", "==", OWNER_UID)
      .get();

    const tokens = tokensSnap.docs.map(d => d.id).filter(Boolean);
    if (!tokens.length) return;

    let when = "Just now";
    const ts = order.createdAt;
    if (ts && typeof ts.toDate === "function") {
      when = ts.toDate().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Kolkata" });
    }

    const customer = order.customerName || "Customer";
    const total = Number(order.total || 0);
    const body = `${customer} • ₹${total} • ${when}`;

    const chunks = [];
    for (let i = 0; i < tokens.length; i += 500) chunks.push(tokens.slice(i, i + 500));

    for (const chunk of chunks) {
      const response = await getMessaging().sendEachForMulticast({
        tokens: chunk,
        notification: {
          title: "New Order — SM RO WATER SERVICE",
          body
        },
        data: {
          type: "NEW_ORDER",
          orderId: snap.id,
          customerName: String(customer),
          total: String(total)
        },
        android: {
          priority: "high",
          notification: {
            channelId: "sm_orders",
            sound: "default"
          }
        }
      });

      const deletes = [];
      response.responses.forEach((r, i) => {
        if (!r.success && r.error && ["messaging/registration-token-not-registered", "messaging/invalid-registration-token"].includes(r.error.code)) {
          deletes.push(db.collection("ownerTokens").doc(chunk[i]).delete());
        }
      });
      if (deletes.length) await Promise.all(deletes);
    }
  }
);
