package com.smwater.service.owner;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.webkit.WebViewAssetLoader;

import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {
    private WebView webView;
    private long lastBack = 0;
    private static final int NOTIFICATION_PERMISSION = 41;

    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(6,19,31));
        getWindow().setNavigationBarColor(Color.rgb(6,19,31));

        try { FirebaseApp.initializeApp(this); } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }

        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        CookieManager.getInstance().setAcceptCookie(true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void getFcmToken(final String callbackName) {
            try {
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                    String token = task.isSuccessful() ? task.getResult() : "";
                    String js = "window." + callbackName + "(" + quote(token) + ")";
                    runOnUiThread(() -> webView.evaluateJavascript(js, null));
                });
            } catch (Exception e) {
                runOnUiThread(() -> webView.evaluateJavascript("window." + callbackName + "('')", null));
            }
        }

        @JavascriptInterface public void localTestNotification() {
            try { OwnerMessagingService.showLocalNotification(MainActivity.this, "Test notification", "SM RO WATER OWNER notifications are active."); }
            catch (Exception e) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "Notification service not configured yet", Toast.LENGTH_SHORT).show()); }
        }

        private String quote(String s) { return "\"" + String.valueOf(s).replace("\\", "\\\\").replace("\"", "\\\"") + "\""; }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) { webView.goBack(); return; }
        if (System.currentTimeMillis() - lastBack < 1800) super.onBackPressed();
        else { lastBack = System.currentTimeMillis(); Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show(); }
    }
}
