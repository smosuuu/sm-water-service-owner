# SM RO WATER SERVICE — Owner Android App

Premium mobile-first owner control app for SM RO WATER SERVICE.

## Included
- Owner-only Firebase login
- Realtime orders and customer profiles
- Order status controls
- Today sales/order counters
- Customer call action
- Native Android push-notification service (FCM)
- Notification token registration from the owner dashboard
- Test notification button
- S25 Ultra / Android adaptive WebView layout
- SM Water launcher icon

## Required once for real push notifications
Register a second Android app in the same Firebase project:

Package name:
`com.smwater.service.owner`

Download its `google-services.json` and place it at:
`app/google-services.json`

Then enable the Google Services Gradle plugin and Firebase Messaging if you want the native FCM registration to use that Firebase Android app. The UI itself uses the existing Firebase web project config.

## Firestore
The dashboard stores the FCM token in:
`ownerTokens/{token}`

Only the owner UID should be allowed to create/update/read/delete these documents.

## Push trigger
The `functions/` folder contains a Firebase Cloud Function that sends an FCM notification whenever a new document is created in `orders/{orderId}`. Deploy it to the same Firebase project after installing dependencies.
